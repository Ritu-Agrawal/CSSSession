import { Component } from '@angular/core';

@Component({
  selector: 'examples',
  templateUrl: './flexexamples.component.html',
  styleUrls: ['./flexexamples.component.css']
})
export class FlexExamplesComponent {
  title = 'Techniques of creating user layout using css3 by Sayed Minhal';

  constructor() {
    console.log("in Flex Examples Component");
  }
}
