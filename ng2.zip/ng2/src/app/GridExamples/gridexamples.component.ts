import { Component } from '@angular/core';

@Component({
  selector: 'examples',
  templateUrl: './gridexamples.component.html',
  styleUrls: ['./gridexamples.component.css']
})
export class GridExamplesComponent {
  title = 'Techniques of creating user layout using css3 by Sayed Minhal';

  constructor() {
    console.log('in Grid Examples Component');
  }
}
