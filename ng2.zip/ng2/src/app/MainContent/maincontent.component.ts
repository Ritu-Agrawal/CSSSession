import { Component } from '@angular/core';

@Component({
  selector: 'main-content',
  templateUrl: './maincontent.component.html',
  styleUrls: ['./maincontent.component.css']
})
export class MainContentComponent {
  title = 'MainContentComponent';

  constructor() {
    console.log('in MainContentComponent');
  }
}
