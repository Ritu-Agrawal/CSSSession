import { Component } from '@angular/core';

@Component({
  selector: 'side-menu',
  templateUrl: './sidemenu.component.html',
  styleUrls: ['./sidemenu.component.css']
})
export class SideMenuComponent {
  title = 'Technique of creating useful layouts using CSS3 by Sayed Minhal';

  constructor() {
    console.log("in SideMenuComponent");
  }
}
