import { Component, ElementRef, Renderer2 } from '@angular/core';
import { RouterModule, Routes, Router, NavigationEnd, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'view-component',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent {
  title = 'View Component';
  routeURL = '';

  constructor(private router: Router, private route: ActivatedRoute, public el: ElementRef, public renderer: Renderer2) {
    console.log('View Component');
  }

  ngOnInit() {
    this.router.events
      .subscribe((event) => {
        if (event instanceof NavigationEnd) {
          console.log(event);
        }
      });

      this.route
      .queryParams
      .subscribe(params => {
        console.log(this.routeURL = params['routeURL']);
        this.renderer.addClass(this.el.nativeElement, this.routeURL);
      });
  }
}
