import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { ViewComponent } from './View/view.component';
import { SideMenuComponent } from './SideMenu/sidemenu.component';
import { MainContentComponent } from './MainContent/maincontent.component';
import { FlexExamplesComponent } from './FlexExamples/flexexamples.component';
import { GridExamplesComponent } from './GridExamples/gridexamples.component';

const appRoutes: Routes = [
   { path: '', component: ViewComponent },
   { path: 'displaygrid', component: ViewComponent },
   { path: 'flexexamples', component: FlexExamplesComponent },
   { path: 'gridexamples', component: GridExamplesComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    ViewComponent,
    SideMenuComponent,
    MainContentComponent,
    FlexExamplesComponent,
    GridExamplesComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
